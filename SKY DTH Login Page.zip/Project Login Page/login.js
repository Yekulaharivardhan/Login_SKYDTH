function validate(){


while(email >0)


var passWrd = document.getElementById("floatingPassword").value;
    var email = document.getElementById("email").value;

    
    if ((email.indexOf('@')<=0) && (email.indexOf(email.length-1)='@') && (email.indexOf('.')<=0)) {
    alert("Please check email ID and Password");
}

    
        else if((email.charAt(email.length -4)!='.') && (email.charAt(email.length-5)!='.') && (email.indexOf('.'<=0)))
        
        {
            alert("Please check email ID and Password");
           
        
        }
      else  
      
    
      var passWrd = document.getElementById("floatingPassword");
      
      if((passWrd.value.length>5) && (passWrd.value.match(/[0-9]/)) && 
      (passWrd.value.match(/[a-z]/)) && (passWrd.value.match(/[A-Z]/)) && (passWrd.value.match(/[!@#$%^&*()_+=/?>~<]/)))  
      {
            alert("Success");
            
    }
        
        else {alert("Please check Password - Password Should Contain Atleast 1-Capital letter, 1-Small Letter, 1-number, 1-Special Character & a minimum of 5 characters in length")}
  


}
